import React from "react";

import { getInitialData } from "../utils/index";
import NoteHeader from "./NoteHeader";
import NoteBody from "./NoteBody";

class NoteApp extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            notes: getInitialData(),
            query: '',
        }

        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onArchiveHandler = this.onArchiveHandler.bind(this);
        this.onAddNoteHandler = this.onAddNoteHandler.bind(this);
        this.onSearchHandler = this.onSearchHandler.bind(this);
        
    }


    onDeleteHandler(id) {
        const notes = this.state.notes.filter(note => note.id !== id);
        this.setState({ notes })
    }

    onArchiveHandler(id) {
        const updatedNotes = this.state.notes.map(note =>
            note.id === id ? { ...note, archived: !note.archived } : note
        );
        this.setState({ notes: updatedNotes })
    }


    onAddNoteHandler({  title, body }) {
        this.setState((prevState) => {
            return {
                notes: [
                    ...prevState.notes,
                    {
                        id: +new Date(),
                        title: title, 
                        body: body,
                        archived: false,
                        createdAt: (new Date()).toISOString(),
                    }
                ]
            }
        });

    }


    onSearchHandler(event) {
        this.setState({ query: event.target.value })
    }


    render() {
        const filteredNotes = this.state.notes.filter(note => note.title.toLowerCase().includes(this.state.query.toLowerCase()));
        return (
            <>
                <NoteHeader query={this.state.query} onSearchHandler={this.onSearchHandler} />
                <NoteBody notes={filteredNotes} addNote={this.onAddNoteHandler} onDelete={this.onDeleteHandler} onArchived={this.onArchiveHandler} />
               
            </>
        );
    }
}

export default NoteApp;