import React from "react";
import NoteItemBody from "./NoteItemBody";
function NoteItem({ id, title, body, archived, createdAt, onDelete, onArchived }) {

    return (
        <div className="note-item">
            <div className="note-item__content">
                <NoteItemBody title={title} body={body} createdAt={createdAt} />
            </div>
            <div className="note-item__action">
                <button className="note-item__archive-button" onClick={ () => onArchived(id)}>{archived ? "Pindahkan" : "Arsipkan"}</button>
                <button  className="note-item__delete-button" onClick={ () => onDelete(id)}>Delete</button>
            </div>
        </div>
    );
    
}

export default NoteItem;