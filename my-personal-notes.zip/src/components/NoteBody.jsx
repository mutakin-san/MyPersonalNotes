import React from "react";
import NoteList from "./NoteList";
import NoteInput from "./NoteInput";

function NoteBody({ notes, addNote, onDelete, onArchived}) {
    const activeNotes = notes.filter((note) => note.archived === false);
    const archivedNotes = notes.filter((note) => note.archived === true);
    return (
        <div className="note-app__body">
             <NoteInput addNote={(addNote)} />
             <h2>Catatan Aktif</h2>
             {!activeNotes.length ? <p className="notes-list__empty-message">Tidak ada catatan</p> : <NoteList notes={activeNotes} onDelete={onDelete} onArchived={onArchived}/>}
             <h2>Arsip</h2>
             {!archivedNotes.length ? <p className="notes-list__empty-message">Tidak ada catatan</p> : <NoteList notes={archivedNotes} onDelete={onDelete} onArchived={onArchived}/>}
        </div>
    );
}

export default NoteBody;