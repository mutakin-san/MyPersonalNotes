import React from "react";
function NoteSearch({ query, onSearchHandler }){
    return (
        <div className="note-search">
            <input type="text" placeholder="Cari Catatan..." value={query} onChange={onSearchHandler} />
        </div>
    );
}


export default NoteSearch;